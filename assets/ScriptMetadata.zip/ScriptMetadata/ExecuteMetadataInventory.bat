@echo off
cd /d "%~dp0"
echo ============================================================
echo   Metadata Inventory - NO SHAREPOINT UPLOAD
echo ============================================================
echo.
echo The script processes only rows where "To Be Uploaded?" = "Yes".
echo No files or folders will be uploaded to SharePoint.
echo A progress bar will be displayed during processing.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ExportMetadataInventory.ps1"
echo.
echo ============================================================
echo   Process finished.
echo ============================================================
pause
