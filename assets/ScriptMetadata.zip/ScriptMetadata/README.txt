﻿Metadata Inventory
==================

FILES
-----
- ExportMetadataInventory.ps1
- ExecuteMetadataInventory.bat

PURPOSE
-------
This tool creates a detailed CSV inventory of the files and folders selected
for migration. It does NOT upload, modify, move, or delete content in SharePoint.

HOW TO USE
----------
1. Place both files inside the original "Migration" folder, next to
   UploadToSharePoint.ps1 and the Modules folder.
2. Run ExecuteMetadataInventory.bat.
3. Select the same Excel workbook used by the migration process.
4. The script processes only rows where "To Be Uploaded?" = "Yes".
5. The script first estimates the number of items and then displays a progress
   bar while the inventory is being generated.
6. Output files are created in:
   Migration\MetadataReports\

CSV FORMAT
----------
The CSV uses a semicolon (;) as the delimiter and UTF-8 encoding.

COLUMN ORGANIZATION
-------------------
The CSV is organized to make migration analysis easier.

1. ITEM IDENTIFICATION
   - ItemType
   - Name
   - BaseName
   - Extension

2. LOCATION AND STRUCTURE
   - FullPath
   - ParentPath
   - SourceRoot
   - RelativePath
   - DepthFromSourceRoot

3. FILE SIZE
   - SizeBytes
   - SizeKB
   - SizeMB
   - SizeGB

4. TIMESTAMPS
   - CreationTime
   - LastWriteTime
   - LastAccessTime
   - CreationTimeUtc
   - LastWriteTimeUtc
   - LastAccessTimeUtc

5. TECHNICAL INFORMATION
   - PathLength
   - NameLength
   - Attributes

6. SOURCE EXCEL REFERENCE
   - ExcelRow
   - IsRootFromExcel
   - All columns copied from the corresponding source Excel row,
     prefixed with "Excel_"

This order keeps the information most commonly used during migration analysis
at the beginning of the CSV and the original migration workbook context at the end.

REMOVED COLUMNS
---------------
The following columns are intentionally not generated:
- AccessPath
- IsReadOnly
- IsHidden
- IsSystem
- IsArchive
- IsCompressed
- IsEncrypted
- IsOffline
- IsReparsePoint
- IsSparseFile
- IsTemporary
- AccessRulesCount
- ACL
- SecurityError
- SHA256

PROGRESS TRACKING
-----------------
The script displays two progress stages:

1. Preparing source list
   Removes overlapping source rows before scanning. If a selected source folder
   is already contained inside another selected source folder, only the
   top-level source is scanned.

2. Preparing inventory
   Counts the items from the optimized source list. The total shown here is
   designed to match the actual number of items that will be processed.

3. Creating metadata inventory
   Displays:
   - Number of processed items
   - Estimated total number of items
   - Completion percentage
   - Current file or folder being processed

NOTES
-----
- The script does not connect to SharePoint.
- The script does not use Add-PnPFile.
- Long Windows paths are supported internally.
- Overlapping source rows are removed before scanning to avoid repeated work.
- Duplicate paths are still protected by an additional duplicate-path safeguard.
- A separate error CSV is created when an item cannot be read.
